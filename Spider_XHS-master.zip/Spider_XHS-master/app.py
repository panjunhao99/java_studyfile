import tkinter as tk
from tkinter import ttk, scrolledtext
from threading import Thread
from loguru import logger
from main import Data_Spider
from xhs_utils.common_utils import init


class LogRedirector:
    def __init__(self, text_widget):
        self.text_widget = text_widget

    def write(self, message):
        self.text_widget.insert(tk.END, message)
        self.text_widget.see(tk.END)

    def flush(self):
        pass


class XHSDownloaderApp:
    def __init__(self, master):
        self.master = master
        master.title("小红书数据下载器 v1.1")
        self.setup_ui()
        self.setup_logger()

        # 初始化爬虫实例
        self.data_spider = Data_Spider()
        self.cookies_str, self.base_path = init()

    def setup_ui(self):
        # 输入区域
        input_frame = ttk.LabelFrame(self.master, text="参数设置")
        input_frame.grid(row=0, column=0, padx=10, pady=5, sticky="nsew")

        # 用户URL输入
        ttk.Label(input_frame, text="用户主页URL:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.user_url_entry = ttk.Entry(input_frame, width=50)
        self.user_url_entry.grid(row=0, column=1, columnspan=2, padx=5, pady=5)

        # 保存选项
        ttk.Label(input_frame, text="保存选项:").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.save_choice = ttk.Combobox(input_frame, values=["excel", "media", "all"], state="readonly")
        self.save_choice.current(0)
        self.save_choice.grid(row=1, column=1, padx=5, pady=5)

        # Excel文件名
        ttk.Label(input_frame, text="Excel文件名:").grid(row=2, column=0, padx=5, pady=5, sticky="w")
        self.excel_name_entry = ttk.Entry(input_frame, width=30)
        self.excel_name_entry.grid(row=2, column=1, padx=5, pady=5)

        # 控制按钮
        btn_frame = ttk.Frame(self.master)
        btn_frame.grid(row=1, column=0, pady=5)
        self.download_btn = ttk.Button(btn_frame, text="开始下载", command=self.start_download)
        self.download_btn.pack(side=tk.LEFT, padx=5)

        # 日志区域
        log_frame = ttk.LabelFrame(self.master, text="执行日志")
        log_frame.grid(row=2, column=0, padx=10, pady=5, sticky="nsew")

        self.log_area = scrolledtext.ScrolledText(log_frame, wrap=tk.WORD, width=80, height=15)
        self.log_area.pack(padx=5, pady=5, fill=tk.BOTH, expand=True)

        # 配置网格布局权重
        self.master.rowconfigure(2, weight=1)
        self.master.columnconfigure(0, weight=1)

    def setup_logger(self):
        # 移除默认处理器
        logger.remove()
        # 添加自定义日志处理器
        logger.add(
            LogRedirector(self.log_area),
            format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <level>{message}</level>",
            level="INFO"
        )

    def validate_input(self):
        user_url = self.user_url_entry.get()
        if not user_url.startswith("https://www.xiaohongshu.com/user/profile/"):
            logger.error("无效的用户主页URL")
            tk.messagebox.showerror("错误", "请输入有效的小红书用户主页URL")
            return False

        if self.save_choice.get() in ["excel", "all"] and not self.excel_name_entry.get():
            logger.error("Excel文件名为空")
            tk.messagebox.showerror("注意", "Excel文件名不设置 默认使用用户昵称")

        return True

    def start_download(self):
        if not self.validate_input():
            return

        Thread(target=self.run_download, daemon=True).start()

    def run_download(self):
        try:
            self.download_btn.config(state="disabled")
            logger.info("开始下载任务...")

            user_url = self.user_url_entry.get()
            save_choice = self.save_choice.get()
            excel_name = self.excel_name_entry.get()

            user_info, success, msg = self.data_spider.spider_user(
                user_url=user_url,
                cookies_str=self.cookies_str,
                base_path=self.base_path,
                save_choice=save_choice,
                excel_name=excel_name
            )
            user_name = user_info['nickname']
            if excel_name == '':
                excel_name = user_name

            self.data_spider.spider_user_all_note(
                user_url=user_url,
                cookies_str=self.cookies_str,
                base_path=self.base_path,
                save_choice=save_choice,
                excel_name=excel_name
            )

            logger.success("数据下载完成！")
            tk.messagebox.showinfo("完成", "数据下载完成！")

        except Exception as e:
            logger.error(f"发生错误: {str(e)}")
            tk.messagebox.showerror("错误", str(e))
        finally:
            self.download_btn.config(state="normal")


if __name__ == "__main__":
    root = tk.Tk()
    app = XHSDownloaderApp(root)
    root.mainloop()